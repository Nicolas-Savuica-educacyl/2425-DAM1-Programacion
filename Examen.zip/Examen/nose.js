document.addEventListener('DOMContentLoaded', function() {

    const pantalla1 = document.getElementById("pantalla1");
    const pantalla2 = document.getElementById("pantalla2");
    
    const itemsLista = document.querySelectorAll(".lista-ciclos ul");
    
    itemsLista.forEach(item => {
        item.addEventListener("click", function() {
            pantalla1.classList.remove("visible");
            pantalla1.classList.add("oculto");
            
            pantalla2.classList.remove("oculto");
            pantalla2.classList.add("visible");
        });
    });
});

document.querySelectorAll(".lista-ciclos ul").forEach(item => {
    item.addEventListener("click", function() {
        pantallas[1].classList.remove("visible");
        pantallas[1].classList.add("oculto");
        
        pantallas[2].classList.remove("oculto");
        pantallas[2].classList.add("visible");
        
        document.getElementById("cicloMostrar").textContent = this.textContent;
    });
});



document.getElementById("volverInicio").addEventListener("click", function() {
    location.reload(); 
});

document.getElementById("botonEnviar").addEventListener("click", function(e) {
    e.preventDefault(); 
    
    const camposObligatorios = document.querySelectorAll("[required]");
    let valido = true;
    
    camposObligatorios.forEach(campo => {
        if (!campo.value.trim()) {
            valido = false;
            campo.style.border = "2px solid red"; 
        }
    });


if (valido) {
    document.getElementById("pantalla2").classList.add("oculto");
    
    const pantalla3 = document.getElementById("pantalla3");
    pantalla3.classList.remove("oculto");

    const datos = {
        ciclo: document.getElementById("ciclo").value,
        familia: document.getElementById("familia").value,
        nombre: document.getElementById("nombre").value,
        apellido: document.getElementById("apellido").value,
        fecha: document.getElementById("fechaNacimiento").value,
        tipoVia: document.getElementById("tipoVia").value,
        direccion: document.getElementById("Dirección").value,
        numero: document.querySelector("input[type='number']").value,
        escalera: document.getElementById("escalera").value,
        piso: document.getElementById("piso").value,
        letra: document.getElementById("letra").value
    };

    const direccionCompleta = [
        datos.tipoVia,
        datos.direccion,
        datos.numero && `Nº ${datos.numero}`,
        datos.escalera && `Esc. ${datos.escalera}`,
        datos.piso && `Piso ${datos.piso}`,
        datos.letra && `Letra ${datos.letra}`
    ].filter(Boolean).join(", ");

    document.getElementById("confirm-ciclo").textContent = datos.ciclo;
    document.getElementById("confirm-familia").textContent = datos.familia;
    document.getElementById("confirm-nombre").textContent = datos.nombre;
    document.getElementById("confirm-apellido").textContent = datos.apellido;
    document.getElementById("confirm-fecha").textContent = datos.fecha;
    document.getElementById("confirm-direccion").textContent = direccionCompleta;
}
});